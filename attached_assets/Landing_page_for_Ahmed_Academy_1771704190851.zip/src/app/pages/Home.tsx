import React, { useEffect, useState } from "react";
import { Navbar } from "../components/Navbar";
import { Hero } from "../components/Hero";
import { Stats } from "../components/Stats";
import { CourseCards } from "../components/CourseCards";
import { Footer } from "../components/Footer";
import { motion, useScroll, useSpring } from "motion/react";

export const Home = () => {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  return (
    <div className="relative min-h-screen bg-background">
      {/* Global Progress Bar */}
      <motion.div
        className="fixed top-0 left-0 right-0 h-1 bg-primary z-[100] origin-left shadow-[0_0_10px_rgba(255,79,0,0.8)]"
        style={{ scaleX }}
      />

      <Navbar />
      
      <main>
        <Hero />
        <Stats />
        <CourseCards />
        
        {/* Additional CTA Section */}
        <section className="py-32 bg-black relative px-6 md:px-12 overflow-hidden">
           <div className="absolute inset-0 carbon-texture opacity-5 pointer-events-none" />
           <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[80vw] h-[80vw] bg-primary/5 rounded-full blur-[120px] pointer-events-none" />
           
           <div className="max-w-4xl mx-auto text-center relative z-10">
              <span className="font-bebas text-primary tracking-[0.5em] uppercase text-sm mb-6 block">Ready to start?</span>
              <h2 className="font-bebas text-6xl md:text-9xl text-white tracking-tighter leading-none mb-12 uppercase italic">
                 Don't just watch. <br />
                 <span className="text-glow">Dominate.</span>
              </h2>
              <button className="font-bebas text-3xl tracking-widest px-16 py-6 bg-white text-black border border-white hover:bg-transparent hover:text-white transition-all duration-300 uppercase shadow-[0_0_40px_rgba(255,255,255,0.2)]">
                 Secure Your Spot
              </button>
           </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};
