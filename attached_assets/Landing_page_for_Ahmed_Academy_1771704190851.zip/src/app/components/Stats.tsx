import React from "react";
import { motion } from "motion/react";
import { Users, Star, Trophy, Clock } from "lucide-react";

export const Stats = () => {
  const stats = [
    { label: "Elite Students", value: "24,000+", icon: <Users size={20} /> },
    { label: "Avg Rating", value: "4.95 / 5.0", icon: <Star size={20} /> },
    { label: "Design Awards", value: "112+", icon: <Trophy size={20} /> },
    { label: "Course Content", value: "180+ HRS", icon: <Clock size={20} /> },
  ];

  return (
    <section className="relative py-24 bg-background overflow-hidden">
      <div className="absolute inset-0 carbon-texture opacity-5 pointer-events-none" />
      
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-8">
        {stats.map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1, duration: 0.6 }}
            viewport={{ once: true }}
            className="glass p-8 flex flex-col items-center justify-center border-l-2 border-l-primary"
          >
            <div className="text-primary mb-4 p-3 bg-primary/10 rounded-full">
              {stat.icon}
            </div>
            <div className="font-bebas text-5xl md:text-6xl text-white tracking-tighter mb-2">
              {stat.value}
            </div>
            <div className="font-bebas text-sm tracking-[0.3em] uppercase opacity-50">
              {stat.label}
            </div>
          </motion.div>
        ))}
      </div>

      {/* Floating glassmorphism course preview element */}
      <motion.div 
        animate={{ y: [0, -20, 0] }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        className="hidden lg:block absolute top-10 right-10 glass p-6 w-64 rotate-3 z-20"
      >
        <div className="flex items-center space-x-4 mb-4">
          <div className="w-12 h-12 bg-primary/20 flex items-center justify-center rounded-lg">
             <Trophy size={24} className="text-primary" />
          </div>
          <div>
            <div className="font-bebas text-lg leading-tight">Mastering UI/UX</div>
            <div className="text-[10px] uppercase tracking-widest opacity-50">Current Lesson</div>
          </div>
        </div>
        <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
           <div className="w-3/4 h-full bg-primary shadow-[0_0_10px_rgba(255,79,0,0.5)]" />
        </div>
        <div className="mt-2 text-[10px] font-bebas tracking-widest uppercase opacity-80 flex justify-between">
            <span>75% Complete</span>
            <span className="text-primary">In Progress</span>
        </div>
      </motion.div>
    </section>
  );
};
