import React from "react";
import { motion } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ArrowRight, Play, Clock } from "lucide-react";

const courses = [
  {
    title: "UI/UX FUNDAMENTALS",
    category: "FOUNDATION",
    image: "https://images.unsplash.com/photo-1755436612946-bd731a91a0ce?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaWdoLXRlY2glMjB1c2VyJTIwaW50ZXJmYWNlJTIwZGVzaWduJTIwM0QlMjBhYnN0cmFjdCUyMGRhcmslMjBvcmFuZ2UlMjBuZW9ufGVufDF8fHx8MTc3MTcwMjU1OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    lessons: "48 Lessons",
    duration: "12 Hours",
    price: "$299"
  },
  {
    title: "ADVANCED PROTOTYPING",
    category: "MASTERY",
    image: "https://images.unsplash.com/photo-1749248120469-c41bf8471a48?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHwzRCUyMHJlbmRlciUyMGFic3RyYWN0JTIwZ2VvbWV0cnklMjBkYXJrJTIwbWV0YWwlMjBvcmFuZ2UlMjBnbG93JTIwc2xlZWslMjBkZXNpZ258ZW58MXx8fHwxNzcxNzAyNTYwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    lessons: "32 Lessons",
    duration: "8 Hours",
    price: "$399"
  },
  {
    title: "DESIGN SYSTEMS AT SCALE",
    category: "ARCHITECTURE",
    image: "https://images.unsplash.com/photo-1614850523296-d8c1af93d400?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkYXJrJTIwYWJzdHJhY3QlMjBkZXNpZ24lMjBvcmFuZ2UlMjBsaW5lc3xlbnwxfHx8fDE3NzE3MDI1NjJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    lessons: "54 Lessons",
    duration: "15 Hours",
    price: "$499"
  }
];

export const CourseCards = () => {
  return (
    <section id="courses" className="py-32 bg-background relative px-6 md:px-12">
       <div className="absolute inset-0 carbon-texture opacity-5 pointer-events-none" />
       
       <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-24">
             <div className="max-w-2xl">
                <span className="font-bebas text-primary tracking-[0.4em] uppercase text-sm mb-4 block">Select your engine</span>
                <h2 className="font-bebas text-6xl md:text-8xl text-white tracking-tighter leading-none mb-6">
                   CHOOSE YOUR <br /><span className="text-glow">MASTERY TRACK</span>
                </h2>
             </div>
             <div className="mt-8 md:mt-0">
                <p className="text-white/40 uppercase tracking-widest text-xs max-w-xs mb-8">
                   Accelerate your career with world-class design curriculum designed for speed and precision.
                </p>
                <div className="w-full h-[1px] bg-white/20 relative">
                   <div className="absolute top-0 left-0 w-1/2 h-full bg-primary shadow-[0_0_10px_rgba(255,79,0,0.8)]" />
                </div>
             </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
             {courses.map((course, index) => (
               <motion.div
                 key={index}
                 initial={{ opacity: 0, scale: 0.95 }}
                 whileInView={{ opacity: 1, scale: 1 }}
                 transition={{ duration: 0.5, delay: index * 0.1 }}
                 viewport={{ once: true }}
                 whileHover={{ y: -10 }}
                 className="group relative bg-black border border-white/10 p-4 transition-all duration-500 hover:border-primary/50"
               >
                 <div className="relative aspect-video overflow-hidden mb-8">
                    <ImageWithFallback
                      src={course.image}
                      alt={course.title}
                      className="w-full h-full object-cover grayscale brightness-110 group-hover:grayscale-0 group-hover:scale-110 transition-all duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                    <div className="absolute bottom-4 left-4 flex space-x-2">
                       <span className="bg-primary px-3 py-1 font-bebas text-xs tracking-widest uppercase">{course.category}</span>
                       <span className="bg-white/10 backdrop-blur-md px-3 py-1 font-bebas text-xs tracking-widest uppercase">{course.lessons}</span>
                    </div>
                    <motion.div 
                      whileHover={{ scale: 1.1 }}
                      className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                    >
                       <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center shadow-[0_0_30px_rgba(255,79,0,0.5)]">
                          <Play fill="white" size={24} className="ml-1" />
                       </div>
                    </motion.div>
                 </div>

                 <div className="space-y-4 px-2">
                    <div className="flex justify-between items-start">
                       <h3 className="font-bebas text-3xl md:text-4xl text-white tracking-tighter group-hover:text-primary transition-colors">
                          {course.title}
                       </h3>
                       <div className="font-bebas text-2xl text-white opacity-40 italic">{course.price}</div>
                    </div>
                    
                    <p className="text-white/40 text-sm leading-relaxed mb-8">
                       Dominate the industry with high-fidelity production techniques and advanced workflows.
                    </p>

                    <div className="flex items-center justify-between pt-6 border-t border-white/5">
                       <div className="flex items-center space-x-2 text-white/40 font-bebas text-xs tracking-widest uppercase">
                          <Clock size={14} />
                          <span>{course.duration} TOTAL</span>
                       </div>
                       <button className="flex items-center space-x-2 text-white hover:text-primary transition-colors font-bebas tracking-widest uppercase group/btn">
                          <span>View Module</span>
                          <ArrowRight size={18} className="group-hover/btn:translate-x-2 transition-transform" />
                       </button>
                    </div>
                 </div>

                 {/* Sharp Corner Accents */}
                 <div className="absolute top-0 right-0 w-8 h-8 border-t border-r border-transparent group-hover:border-primary/50 transition-colors" />
                 <div className="absolute bottom-0 left-0 w-8 h-8 border-b border-l border-transparent group-hover:border-primary/50 transition-colors" />
               </motion.div>
             ))}
          </div>
       </div>
    </section>
  );
};
