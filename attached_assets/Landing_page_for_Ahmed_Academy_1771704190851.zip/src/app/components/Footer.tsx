import React from "react";
import { Instagram, Twitter, Youtube, ArrowRight } from "lucide-react";

export const Footer = () => {
  return (
    <footer className="bg-background py-24 border-t border-white/5 relative overflow-hidden px-6 md:px-12">
      <div className="absolute inset-0 carbon-texture opacity-5 pointer-events-none" />
      
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-16">
        <div className="md:col-span-2">
          <div className="flex items-center space-x-2 mb-8">
            <div className="w-8 h-8 bg-primary rotate-45 flex items-center justify-center">
              <span className="font-bebas text-white -rotate-45 text-xl">A</span>
            </div>
            <span className="font-bebas text-2xl tracking-tighter uppercase italic text-white">
              Ahmed Academy
            </span>
          </div>
          <p className="text-white/40 max-w-sm mb-8 text-sm uppercase tracking-widest leading-relaxed">
            The future of design education is high-performance. Master the craft with Ahmed and transform your career into a masterpiece of precision.
          </p>
          <div className="flex space-x-6 text-white/50">
            <a href="#" className="hover:text-primary transition-colors duration-300"><Instagram size={20} /></a>
            <a href="#" className="hover:text-primary transition-colors duration-300"><Twitter size={20} /></a>
            <a href="#" className="hover:text-primary transition-colors duration-300"><Youtube size={20} /></a>
          </div>
        </div>

        <div>
          <h4 className="font-bebas text-lg tracking-[0.3em] uppercase text-white mb-8 border-b border-primary/30 inline-block">Curriculum</h4>
          <ul className="space-y-4 font-bebas text-white/40 tracking-widest uppercase text-sm">
            <li><a href="#" className="hover:text-white transition-colors">UI Design</a></li>
            <li><a href="#" className="hover:text-white transition-colors">UX Research</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Prototyping</a></li>
            <li><a href="#" className="hover:text-white transition-colors">Design Systems</a></li>
          </ul>
        </div>

        <div>
          <h4 className="font-bebas text-lg tracking-[0.3em] uppercase text-white mb-8 border-b border-primary/30 inline-block">Newsletter</h4>
          <p className="text-white/40 text-xs mb-4 uppercase tracking-widest">Fuel your inbox with design updates.</p>
          <div className="relative border border-white/10 group-focus-within:border-primary transition-colors">
            <input 
              type="email" 
              placeholder="YOUR EMAIL ADDRESS" 
              className="w-full bg-transparent px-4 py-3 text-xs font-bebas tracking-widest outline-none text-white uppercase placeholder:text-white/20"
            />
            <button className="absolute right-2 top-1/2 -translate-y-1/2 text-white hover:text-primary transition-colors">
              <ArrowRight size={20} />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto mt-24 pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center text-[10px] font-bebas tracking-[0.4em] uppercase text-white/20">
        <div>© 2026 Ahmed Academy. All rights reserved.</div>
        <div className="flex space-x-8 mt-4 md:mt-0">
          <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
          <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          <a href="#" className="hover:text-white transition-colors">Contact</a>
        </div>
      </div>
    </footer>
  );
};
