import React from "react";
import { motion, useScroll, useTransform } from "motion/react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export const Hero = () => {
  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 500], [0, 200]);
  const y2 = useTransform(scrollY, [0, 500], [0, -200]);

  const creatorPortrait = "https://images.unsplash.com/photo-1624670319970-37aa780d4874?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGFyaXNtYXRpYyUyMG1hbiUyMHBvcnRyYWl0JTIwcHJvZmVzc2lvbmFsJTIwbGlnaHRpbmclMjBzaGFsbG93JTIwZGVwdGglMjBvZiUyMGZpZWxkJTIwYmxhY2slMjBiYWNrZ3JvdW5kfGVufDF8fHx8MTc3MTcwMjUzNnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral";

  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden bg-background">
      {/* Carbon Fiber Background */}
      <div className="absolute inset-0 carbon-texture opacity-10 pointer-events-none" />

      {/* Bokeh Streaks */}
      <div className="bokeh-streak top-1/4 -left-20 rotate-12" />
      <div className="bokeh-streak bottom-1/3 -right-20 -rotate-12" />
      <div className="bokeh-streak top-2/3 left-1/2 -translate-x-1/2 opacity-10" />

      {/* Kinetic Typography */}
      <div className="absolute inset-0 flex flex-col justify-center space-y-[-5rem] opacity-20 select-none pointer-events-none z-0">
        <div className="kinetic-container">
          <div className="kinetic-text font-bebas text-[20vw] uppercase leading-none text-white/50 tracking-tighter">
            MASTER THE CRAFT MASTER THE CRAFT MASTER THE CRAFT MASTER THE CRAFT&nbsp;
          </div>
          <div className="kinetic-text font-bebas text-[20vw] uppercase leading-none text-white/50 tracking-tighter">
            MASTER THE CRAFT MASTER THE CRAFT MASTER THE CRAFT MASTER THE CRAFT&nbsp;
          </div>
        </div>
        <div className="kinetic-container">
          <div className="kinetic-text font-bebas text-[20vw] uppercase leading-none text-white/50 tracking-tighter" style={{ animationDirection: 'reverse' }}>
             LIMITLESS PERFORMANCE LIMITLESS PERFORMANCE LIMITLESS PERFORMANCE&nbsp;
          </div>
          <div className="kinetic-text font-bebas text-[20vw] uppercase leading-none text-white/50 tracking-tighter" style={{ animationDirection: 'reverse' }}>
             LIMITLESS PERFORMANCE LIMITLESS PERFORMANCE LIMITLESS PERFORMANCE&nbsp;
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-6 flex flex-col items-center">
        
        {/* Creator Portrait with Kinetic Text Overlay Effect */}
        <div className="relative w-full max-w-2xl aspect-[3/4] md:aspect-[4/5] overflow-visible">
           {/* Behind text */}
           <div className="absolute inset-0 flex items-center justify-center z-0">
               <h1 className="font-bebas text-[15vw] md:text-[10rem] uppercase leading-none text-white text-glow tracking-tighter text-center">
                  MASTER THE CRAFT
               </h1>
           </div>

           {/* Portrait */}
           <motion.div 
            style={{ y: y1 }}
            className="absolute inset-0 z-10 pointer-events-none"
           >
              <ImageWithFallback
                src={creatorPortrait}
                alt="Ahmed - Lead Creator"
                className="w-full h-full object-cover grayscale brightness-125"
                style={{ maskImage: 'linear-gradient(to top, transparent, black 20%, black 80%, transparent)' }}
              />
           </motion.div>

           {/* Front text (Cut out effect implied by layering or partial opacity) */}
           <div className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none">
                <h1 className="font-bebas text-[15vw] md:text-[10rem] uppercase leading-none text-transparent border-text tracking-tighter text-center" 
                    style={{ WebkitTextStroke: '1px rgba(255,255,255,0.8)' }}>
                  MASTER THE CRAFT
                </h1>
           </div>
        </div>

        {/* Call to Action */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1, duration: 0.8 }}
          className="mt-[-4rem] z-30 flex flex-col items-center"
        >
          <p className="text-white tracking-[0.3em] uppercase text-sm mb-8 opacity-80">
             The ultimate design academy for high-performance creatives
          </p>
          <div className="flex space-x-6">
             <button className="font-bebas text-2xl tracking-widest px-12 py-4 bg-primary text-white border border-primary hover:bg-transparent hover:text-primary transition-all duration-300 shadow-[0_0_30px_rgba(255,79,0,0.4)] uppercase">
                Start Learning
             </button>
             <button className="font-bebas text-2xl tracking-widest px-12 py-4 border border-white/30 text-white hover:bg-white hover:text-black transition-all duration-300 uppercase">
                Explore Courses
             </button>
          </div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 flex flex-col items-center space-y-4">
        <span className="font-bebas text-xs tracking-[0.5em] uppercase opacity-40">Scroll to race</span>
        <div className="w-[1px] h-16 bg-gradient-to-b from-primary to-transparent" />
      </div>
    </section>
  );
};
