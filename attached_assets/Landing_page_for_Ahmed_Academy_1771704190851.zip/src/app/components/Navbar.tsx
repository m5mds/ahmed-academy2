import React from "react";
import { motion } from "motion/react";

export const Navbar = () => {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 px-6 py-8 md:px-12 flex justify-between items-center bg-transparent backdrop-blur-sm">
      <div className="flex items-center space-x-2">
        <div className="w-8 h-8 bg-primary rotate-45 flex items-center justify-center">
          <span className="font-bebas text-white -rotate-45 text-xl">A</span>
        </div>
        <span className="font-bebas text-2xl tracking-tighter uppercase italic">
          Ahmed Academy
        </span>
      </div>

      <div className="hidden md:flex space-x-12 font-bebas text-lg tracking-widest uppercase">
        <a href="#courses" className="hover:text-primary transition-colors duration-300">Courses</a>
        <a href="#about" className="hover:text-primary transition-colors duration-300">About</a>
        <a href="#testimonials" className="hover:text-primary transition-colors duration-300">Community</a>
      </div>

      <div className="flex items-center space-x-4">
        <button className="font-bebas tracking-widest uppercase text-sm border border-white/20 px-6 py-2 hover:bg-white hover:text-black transition-all duration-300">
          Login
        </button>
        <button className="font-bebas tracking-widest uppercase text-sm bg-primary border border-primary px-6 py-2 hover:bg-transparent hover:text-primary transition-all duration-300 shadow-[0_0_15px_rgba(255,79,0,0.3)]">
          Enroll Now
        </button>
      </div>
    </nav>
  );
};
