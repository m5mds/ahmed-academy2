
  # Landing page for Ahmed Academy

  This is a code bundle for Landing page for Ahmed Academy. The original project is available at https://www.figma.com/design/L29ZRU5J7627PHD37UDH1h/Landing-page-for-Ahmed-Academy.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  