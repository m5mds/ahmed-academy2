
  # Educational Infrastructure Overview

  This is a code bundle for Educational Infrastructure Overview. The original project is available at https://www.figma.com/design/SNYvuoO6wibLm0icp9UQVU/Educational-Infrastructure-Overview.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  