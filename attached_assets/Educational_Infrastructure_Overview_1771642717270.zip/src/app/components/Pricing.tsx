import { motion, useScroll, useTransform } from 'motion/react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Check, Star, Sparkles, Crown } from 'lucide-react';
import { useRef, useState } from 'react';

const pricingTiers = [
  {
    name: 'الفصل الأول',
    code: 'MID1',
    price: '500',
    description: 'ابدأ رحلتك التعليمية بمحتوى الفصل الدراسي الأول',
    features: [
      'الوصول الكامل لدروس الفصل الأول',
      'الدروس المباشرة التفاعلية',
      'التسجيلات المحفوظة',
      'اختبارات وتقييمات دورية',
      'شهادة إتمام',
      'دعم فني 24/7',
    ],
    popular: false,
    gradient: 'from-blue-500 to-cyan-500',
  },
  {
    name: 'الفصل الثاني',
    code: 'MID2',
    price: '500',
    description: 'استكمل مسيرتك مع محتوى الفصل الدراسي الثاني',
    features: [
      'كل مميزات الفصل الأول',
      'الوصول الكامل لدروس الفصل الثاني',
      'مواد مراجعة متقدمة',
      'ورش عمل حصرية',
      'جلسات أسئلة وأجوبة',
      'أولوية في الدعم الفني',
    ],
    popular: true,
    gradient: 'from-purple-500 to-pink-500',
  },
  {
    name: 'الاستعداد النهائي',
    code: 'FINAL',
    price: '600',
    description: 'استعد للامتحانات النهائية بمراجعة شاملة',
    features: [
      'مراجعة نهائية مكثفة',
      'نماذج امتحانات سابقة',
      'تدريبات عملية',
      'جلسات حل أسئلة مباشرة',
      'توقعات الامتحانات',
      'ضمان النجاح',
    ],
    popular: false,
    gradient: 'from-orange-500 to-red-500',
  },
  {
    name: 'الباقة الشاملة',
    code: 'FULL',
    price: '1400',
    description: 'الوصول الكامل لجميع المحتويات طوال العام الدراسي',
    features: [
      'كل المحتويات السابقة',
      'وصول غير محدود للمنصة',
      'جميع المواد الإضافية',
      'مكتبة الموارد الكاملة',
      'خصم 20% على الإجمالي',
      'دعم VIP مخصص',
    ],
    popular: false,
    gradient: 'from-green-500 to-emerald-500',
    badge: 'الأفضل قيمة',
  },
];

function PricingCard({ tier, index }: { tier: typeof pricingTiers[0], index: number }) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [isHovered, setIsHovered] = useState(false);

  const { scrollYProgress } = useScroll({
    target: cardRef,
    offset: ["start end", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], [100, -100]);
  const rotateX = useTransform(scrollYProgress, [0, 0.5, 1], [15, 0, -15]);

  return (
    <motion.div
      ref={cardRef}
      initial={{ opacity: 0, y: 50, rotateX: 20 }}
      whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
      viewport={{ once: true, margin: '-100px' }}
      transition={{ 
        duration: 0.8, 
        delay: index * 0.1,
        type: "spring",
        stiffness: 100,
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        transformStyle: 'preserve-3d',
        rotateX: tier.popular ? 0 : rotateX,
      }}
      className="h-full"
    >
      <motion.div
        animate={isHovered ? {
          y: -10,
          scale: 1.02,
        } : {}}
        transition={{ type: "spring", stiffness: 300, damping: 20 }}
      >
        <Card className={`p-8 h-full flex flex-col relative overflow-hidden ${
          tier.popular 
            ? 'border-purple-500 border-2 shadow-2xl shadow-purple-500/30' 
            : 'border-border/50 hover:border-primary/50'
        }`}>
          {/* Animated background gradient */}
          <motion.div
            className={`absolute inset-0 bg-gradient-to-br ${tier.gradient} opacity-0`}
            animate={isHovered ? { opacity: 0.05 } : { opacity: 0 }}
            transition={{ duration: 0.3 }}
          />

          {/* Popular badge */}
          {tier.popular && (
            <motion.div
              className="absolute top-0 right-0 bg-gradient-to-br from-purple-500 to-pink-500 text-white px-4 py-2 text-sm font-bold rounded-bl-2xl flex items-center gap-2 shadow-lg"
              initial={{ x: 100, y: -100, rotate: 45 }}
              animate={{ x: 0, y: 0, rotate: 0 }}
              transition={{ type: "spring", stiffness: 200, delay: 0.3 }}
              style={{
                transformStyle: 'preserve-3d',
                transform: 'translateZ(30px)',
              }}
            >
              <Star className="w-4 h-4 fill-white" />
              الأكثر شعبية
            </motion.div>
          )}

          {tier.badge && !tier.popular && (
            <motion.div
              className="absolute top-0 right-0 bg-gradient-to-br from-green-500 to-emerald-500 text-white px-4 py-2 text-sm font-bold rounded-bl-2xl flex items-center gap-2 shadow-lg"
              style={{
                transformStyle: 'preserve-3d',
                transform: 'translateZ(30px)',
              }}
            >
              <Crown className="w-4 h-4" />
              {tier.badge}
            </motion.div>
          )}

          <motion.div 
            className="mb-6"
            style={{
              transform: 'translateZ(40px)',
              transformStyle: 'preserve-3d',
            }}
          >
            <motion.div
              className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${tier.gradient} p-3.5 mb-4 shadow-xl relative`}
              animate={isHovered ? {
                rotateY: 360,
                scale: [1, 1.1, 1],
              } : {}}
              transition={{ 
                rotateY: { duration: 0.8 },
                scale: { duration: 0.3 }
              }}
              style={{
                transformStyle: 'preserve-3d',
              }}
            >
              <div className="w-full h-full bg-white/30 rounded-lg backdrop-blur-sm" />
              
              {/* Glow effect */}
              <motion.div
                className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${tier.gradient} blur-xl opacity-0`}
                animate={isHovered ? { opacity: 0.6 } : { opacity: 0 }}
              />
            </motion.div>

            <h3 className="text-3xl font-bold mb-2">{tier.name}</h3>
            <p className="text-sm text-muted-foreground mb-4 leading-relaxed">{tier.description}</p>
            
            <div className="flex items-baseline gap-2 mb-2">
              <motion.span 
                className="text-5xl font-bold bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text"
                animate={isHovered ? {
                  scale: [1, 1.1, 1],
                } : {}}
                transition={{ duration: 0.3 }}
              >
                {tier.price}
              </motion.span>
              <span className="text-muted-foreground text-lg">ريال</span>
            </div>
            <p className="text-xs text-muted-foreground">كود الباقة: {tier.code}</p>
          </motion.div>

          <motion.ul 
            className="space-y-4 mb-8 flex-grow"
            style={{
              transform: 'translateZ(20px)',
              transformStyle: 'preserve-3d',
            }}
          >
            {tier.features.map((feature, featureIndex) => (
              <motion.li
                key={featureIndex}
                className="flex items-start gap-3"
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.05 * featureIndex }}
              >
                <motion.div
                  whileHover={{ scale: 1.2, rotate: 360 }}
                  transition={{ duration: 0.3 }}
                >
                  <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                </motion.div>
                <span className="text-sm leading-relaxed">{feature}</span>
              </motion.li>
            ))}
          </motion.ul>

          <motion.div
            style={{
              transform: 'translateZ(30px)',
              transformStyle: 'preserve-3d',
            }}
          >
            <Button
              className={`w-full py-6 text-lg relative overflow-hidden group ${
                tier.popular
                  ? 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white shadow-lg shadow-purple-500/30'
                  : ''
              }`}
              variant={tier.popular ? 'default' : 'outline'}
            >
              <motion.span
                className="absolute inset-0 bg-white/20"
                initial={{ x: '-100%' }}
                whileHover={{ x: '100%' }}
                transition={{ duration: 0.5 }}
              />
              <span className="relative">اشترك الآن</span>
            </Button>
          </motion.div>
        </Card>
      </motion.div>
    </motion.div>
  );
}

export function Pricing() {
  return (
    <section className="py-32 bg-background relative overflow-hidden">
      {/* 3D Background Elements */}
      <div className="absolute inset-0 opacity-30">
        {[...Array(30)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-primary rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              scale: [0, 1, 0],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: Math.random() * 5,
            }}
          />
        ))}
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <motion.div
            className="inline-flex items-center gap-2 bg-primary/5 px-6 py-3 rounded-full mb-6 border border-primary/20"
            whileHover={{ scale: 1.05 }}
            style={{
              transformStyle: 'preserve-3d',
            }}
          >
            <Sparkles className="w-5 h-5 text-primary" />
            <span className="text-primary font-semibold">خطط مرنة لكل احتياجاتك</span>
          </motion.div>

          <h2 className="text-4xl sm:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
            اختر الباقة المناسبة لك
          </h2>
          <p className="text-muted-foreground text-xl max-w-3xl mx-auto leading-relaxed">
            نظام اشتراكات ذكي مع تحكم دقيق يضمن حصولك على المحتوى المناسب لمرحلتك الدراسية
          </p>
        </motion.div>

        <div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
          style={{
            perspective: '2000px',
            transformStyle: 'preserve-3d',
          }}
        >
          {pricingTiers.map((tier, index) => (
            <PricingCard key={index} tier={tier} index={index} />
          ))}
        </div>

        <motion.div
          className="mt-16 text-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <p className="text-muted-foreground">
            جميع الباقات تشمل ضمان استرجاع المال خلال 7 أيام • الأسعار شاملة ضريبة القيمة المضافة
          </p>
        </motion.div>
      </div>
    </section>
  );
}
