import { motion, useScroll, useTransform } from 'motion/react';
import { Button } from './ui/button';
import { ArrowLeft, Sparkles, Zap, Rocket } from 'lucide-react';
import { useRef } from 'react';

export function CTA() {
  const sectionRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start end", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], [100, -100]);
  const rotateX = useTransform(scrollYProgress, [0, 0.5, 1], [10, 0, -10]);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [0.9, 1, 0.9]);

  return (
    <section ref={sectionRef} className="py-32 relative overflow-hidden">
      {/* Dynamic 3D background */}
      <motion.div 
        className="absolute inset-0 bg-gradient-to-br from-blue-600 via-indigo-700 to-purple-800 dark:from-blue-900 dark:via-indigo-950 dark:to-purple-950"
        style={{ scale }}
      >
        {/* Animated gradient overlay */}
        <motion.div
          className="absolute inset-0"
          animate={{
            background: [
              'radial-gradient(circle at 20% 30%, rgba(120, 119, 198, 0.4) 0%, transparent 60%)',
              'radial-gradient(circle at 80% 70%, rgba(168, 85, 247, 0.4) 0%, transparent 60%)',
              'radial-gradient(circle at 50% 50%, rgba(59, 130, 246, 0.4) 0%, transparent 60%)',
              'radial-gradient(circle at 20% 30%, rgba(120, 119, 198, 0.4) 0%, transparent 60%)',
            ],
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "linear"
          }}
        />

        {/* Floating 3D shapes */}
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-4 h-4 border-2 border-white/20 backdrop-blur-sm"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              transformStyle: 'preserve-3d',
            }}
            animate={{
              y: [0, -150, 0],
              rotateX: [0, 360],
              rotateY: [0, 360],
              rotateZ: [0, 360],
              opacity: [0.2, 0.8, 0.2],
              scale: [1, 1.5, 1],
            }}
            transition={{
              duration: 15 + Math.random() * 10,
              repeat: Infinity,
              delay: Math.random() * 5,
              ease: "easeInOut"
            }}
          />
        ))}

        {/* Large animated orbs */}
        {[...Array(3)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-96 h-96 rounded-full"
            style={{
              background: `radial-gradient(circle, ${
                ['rgba(59, 130, 246, 0.3)', 'rgba(168, 85, 247, 0.3)', 'rgba(236, 72, 153, 0.3)'][i]
              }, transparent)`,
              left: `${(i * 40) % 100}%`,
              top: `${(i * 35) % 100}%`,
              filter: 'blur(80px)',
            }}
            animate={{
              x: [0, 100 * (i % 2 ? 1 : -1), 0],
              y: [0, 100 * (i % 2 ? -1 : 1), 0],
              scale: [1, 1.3, 1],
            }}
            transition={{
              duration: 20 + i * 3,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          />
        ))}
      </motion.div>

      <motion.div
        className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8"
        style={{ 
          y,
          rotateX,
          transformStyle: 'preserve-3d',
        }}
      >
        <div className="text-center">
          {/* Floating badge */}
          <motion.div
            initial={{ opacity: 0, y: -50, rotateX: 90 }}
            whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="mb-8"
          >
            <motion.div
              className="inline-flex items-center gap-3 bg-white/10 backdrop-blur-md px-6 py-3 rounded-full border border-white/30"
              animate={{
                y: [0, -8, 0],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              whileHover={{ 
                scale: 1.05,
                boxShadow: '0 20px 60px rgba(255,255,255,0.3)',
              }}
              style={{
                transformStyle: 'preserve-3d',
                transform: 'translateZ(50px)',
              }}
            >
              <motion.div
                animate={{
                  rotate: [0, 360],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  ease: "linear"
                }}
              >
                <Sparkles className="w-5 h-5 text-yellow-300" />
              </motion.div>
              <span className="text-white font-semibold">عرض محدود: خصم 20% على الباقة الشاملة</span>
              <motion.div
                animate={{
                  scale: [1, 1.2, 1],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                }}
              >
                <Zap className="w-5 h-5 text-yellow-300 fill-yellow-300" />
              </motion.div>
            </motion.div>
          </motion.div>

          {/* Main heading */}
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.9 }}
            whileInView={{ opacity: 1, y: 0, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            style={{
              transformStyle: 'preserve-3d',
              transform: 'translateZ(40px)',
            }}
          >
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
              <motion.span
                className="inline-block"
                animate={{
                  textShadow: [
                    '0 0 20px rgba(255,255,255,0.3)',
                    '0 0 40px rgba(255,255,255,0.6)',
                    '0 0 20px rgba(255,255,255,0.3)',
                  ],
                }}
                transition={{ duration: 3, repeat: Infinity }}
              >
                جاهز لبداية
              </motion.span>
              <br />
              <span className="bg-gradient-to-r from-yellow-300 via-orange-400 to-pink-400 bg-clip-text text-transparent">
                رحلتك التعليمية؟
              </span>
            </h2>
          </motion.div>

          <motion.p
            className="text-xl sm:text-2xl text-blue-100 mb-12 max-w-3xl mx-auto leading-relaxed"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.4 }}
            style={{
              transform: 'translateZ(30px)',
            }}
          >
            انضم إلى آلاف الطلاب الذين حققوا أهدافهم التعليمية مع أكاديمية أحمد. ابدأ اليوم واحصل على وصول فوري لكل المحتويات.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            className="flex flex-col sm:flex-row gap-6 justify-center items-center mb-12"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.6 }}
            style={{
              transformStyle: 'preserve-3d',
            }}
          >
            <motion.div
              whileHover={{ 
                scale: 1.05,
                rotateX: 5,
                rotateY: -5,
              }}
              whileTap={{ scale: 0.95 }}
              style={{ 
                transformStyle: 'preserve-3d',
                transform: 'translateZ(50px)',
              }}
            >
              <Button
                size="lg"
                className="bg-white text-indigo-700 hover:bg-blue-50 px-10 py-7 text-xl shadow-2xl relative overflow-hidden group"
              >
                {/* Animated shine effect */}
                <motion.div
                  className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent"
                  animate={{
                    x: ['-100%', '200%'],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    repeatDelay: 1,
                  }}
                />
                
                <span className="relative flex items-center gap-2">
                  <Rocket className="w-6 h-6" />
                  ابدأ مجاناً الآن
                  <ArrowLeft className="w-5 h-5 group-hover:-translate-x-1 transition-transform" />
                </span>
              </Button>
            </motion.div>

            <motion.div
              whileHover={{ 
                scale: 1.05,
                rotateX: -5,
                rotateY: 5,
              }}
              whileTap={{ scale: 0.95 }}
              style={{ 
                transformStyle: 'preserve-3d',
                transform: 'translateZ(50px)',
              }}
            >
              <Button
                size="lg"
                variant="outline"
                className="bg-white/10 border-white/30 text-white hover:bg-white/20 px-10 py-7 text-xl backdrop-blur-md"
              >
                تحدث مع مستشار تعليمي
              </Button>
            </motion.div>
          </motion.div>

          {/* Trust indicators */}
          <motion.div
            className="flex flex-wrap gap-8 justify-center items-center text-blue-200"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.8 }}
            style={{
              transform: 'translateZ(20px)',
            }}
          >
            {[
              { icon: '✓', text: 'بدون بطاقة ائتمان' },
              { icon: '✓', text: 'إلغاء في أي وقت' },
              { icon: '✓', text: 'ضمان استرجاع المال' },
            ].map((item, i) => (
              <motion.div
                key={i}
                className="flex items-center gap-2 font-medium"
                whileHover={{ 
                  scale: 1.1,
                  color: '#ffffff',
                }}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.9 + i * 0.1 }}
              >
                <motion.span
                  className="text-2xl"
                  animate={{
                    rotateY: [0, 360],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    delay: i * 0.5,
                  }}
                >
                  {item.icon}
                </motion.span>
                {item.text}
              </motion.div>
            ))}
          </motion.div>

          {/* Social proof */}
          <motion.div
            className="mt-16 flex items-center justify-center gap-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 1 }}
          >
            <div className="flex -space-x-2">
              {[1, 2, 3, 4, 5].map((i) => (
                <motion.div
                  key={i}
                  className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-400 to-purple-500 border-4 border-white/20"
                  initial={{ opacity: 0, scale: 0 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ delay: 1.1 + i * 0.1 }}
                  whileHover={{ scale: 1.2, zIndex: 10 }}
                  style={{
                    transformStyle: 'preserve-3d',
                  }}
                />
              ))}
            </div>
            <motion.p
              className="text-white/90 font-medium"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 1.6 }}
            >
              +200 طالب انضم اليوم
            </motion.p>
          </motion.div>
        </div>
      </motion.div>

      {/* Bottom decorative line */}
      <motion.div 
        className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-white/40 to-transparent"
        initial={{ scaleX: 0 }}
        whileInView={{ scaleX: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1.5, delay: 0.5 }}
      />
    </section>
  );
}
