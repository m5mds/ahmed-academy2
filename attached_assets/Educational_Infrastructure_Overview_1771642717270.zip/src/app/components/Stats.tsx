import { motion, useMotionValue, useSpring, useTransform } from 'motion/react';
import { Card } from './ui/card';
import { TrendingUp, Users, Video, Clock } from 'lucide-react';
import { useRef } from 'react';

const stats = [
  {
    icon: Users,
    number: '5,247',
    label: 'طالب نشط',
    color: 'from-blue-500 to-cyan-500',
    trend: '+12%',
  },
  {
    icon: Video,
    number: '256',
    label: 'درس تفاعلي',
    color: 'from-purple-500 to-pink-500',
    trend: '+8%',
  },
  {
    icon: Clock,
    number: '42,891',
    label: 'ساعة مشاهدة',
    color: 'from-orange-500 to-red-500',
    trend: '+23%',
  },
  {
    icon: TrendingUp,
    number: '98.4%',
    label: 'معدل النجاح',
    color: 'from-green-500 to-emerald-500',
    trend: '+3%',
  },
];

function StatCard({ stat, index }: { stat: typeof stats[0], index: number }) {
  const cardRef = useRef<HTMLDivElement>(null);
  
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const rotateX = useSpring(useTransform(mouseY, [-0.5, 0.5], ['10deg', '-10deg']));
  const rotateY = useSpring(useTransform(mouseX, [-0.5, 0.5], ['-10deg', '10deg']));

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    
    const rect = cardRef.current.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    
    const mouseXPos = e.clientX - rect.left;
    const mouseYPos = e.clientY - rect.top;
    
    const xPct = mouseXPos / width - 0.5;
    const yPct = mouseYPos / height - 0.5;
    
    mouseX.set(xPct);
    mouseY.set(yPct);
  };

  const handleMouseLeave = () => {
    mouseX.set(0);
    mouseY.set(0);
  };

  return (
    <motion.div
      ref={cardRef}
      initial={{ opacity: 0, y: 50, scale: 0.8, rotateX: 45 }}
      whileInView={{ opacity: 1, y: 0, scale: 1, rotateX: 0 }}
      viewport={{ once: true, margin: '-100px' }}
      transition={{ 
        duration: 0.8, 
        delay: index * 0.1,
        type: "spring",
        stiffness: 100,
      }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{
        rotateX,
        rotateY,
        transformStyle: 'preserve-3d',
      }}
    >
      <Card className="p-8 hover:shadow-2xl transition-all duration-300 border-border/50 group cursor-pointer relative overflow-hidden bg-gradient-to-br from-background to-secondary/20">
        {/* Animated glow */}
        <motion.div
          className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-10`}
          animate={{
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
          }}
        />

        {/* Shine effect */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full"
          transition={{ duration: 1 }}
        />

        <motion.div
          style={{
            transform: 'translateZ(50px)',
            transformStyle: 'preserve-3d',
          }}
        >
          <motion.div
            className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${stat.color} p-3.5 mb-6 shadow-xl relative`}
            whileHover={{ 
              scale: 1.1,
              rotateY: 360,
            }}
            transition={{ 
              rotateY: { duration: 0.8 },
              scale: { duration: 0.2 }
            }}
            style={{
              transformStyle: 'preserve-3d',
              transform: 'translateZ(30px)',
            }}
          >
            <stat.icon className="w-full h-full text-white" />
            
            {/* Icon glow */}
            <motion.div
              className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${stat.color} blur-2xl opacity-0 group-hover:opacity-70`}
              animate={{
                scale: [1, 1.3, 1],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
              }}
            />
          </motion.div>
        </motion.div>

        <motion.div 
          className="space-y-2"
          style={{
            transform: 'translateZ(40px)',
            transformStyle: 'preserve-3d',
          }}
        >
          <div className="flex items-baseline justify-between">
            <motion.span
              className="text-4xl font-bold bg-gradient-to-r from-foreground to-foreground/60 bg-clip-text"
              initial={{ opacity: 0, scale: 0.5 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.4 + index * 0.1 }}
            >
              {stat.number}
            </motion.span>
            
            <motion.div
              className="flex items-center gap-1 text-sm font-bold text-green-600 dark:text-green-400 bg-green-500/10 px-3 py-1 rounded-full"
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.6 + index * 0.1 }}
              whileHover={{ scale: 1.1 }}
            >
              <TrendingUp className="w-3 h-3" />
              {stat.trend}
            </motion.div>
          </div>
          
          <p className="text-muted-foreground text-lg">{stat.label}</p>
        </motion.div>

        {/* Corner decoration */}
        <motion.div
          className={`absolute -bottom-12 -right-12 w-32 h-32 rounded-full bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-20 blur-3xl`}
          style={{
            transform: 'translateZ(-20px)',
          }}
        />
      </Card>
    </motion.div>
  );
}

export function Stats() {
  return (
    <section className="py-32 bg-background relative overflow-hidden">
      {/* 3D Grid Background */}
      <div className="absolute inset-0">
        <motion.div
          className="absolute inset-0 opacity-[0.03]"
          animate={{
            backgroundPosition: ['0px 0px', '60px 60px'],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: "linear"
          }}
          style={{
            backgroundImage: `
              linear-gradient(to right, currentColor 1px, transparent 1px),
              linear-gradient(to bottom, currentColor 1px, transparent 1px)
            `,
            backgroundSize: '60px 60px',
          }}
        />
      </div>

      {/* Floating orbs */}
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-64 h-64 rounded-full blur-3xl opacity-20"
          style={{
            background: `radial-gradient(circle, ${
              ['#3b82f6', '#8b5cf6', '#ec4899', '#10b981'][i % 4]
            }, transparent)`,
            left: `${(i * 25) % 100}%`,
            top: `${(i * 30) % 100}%`,
          }}
          animate={{
            x: [0, 100, 0],
            y: [0, -100, 0],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 15 + i * 2,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      ))}
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <motion.div
            className="inline-block mb-6"
            animate={{
              rotateY: [0, 360],
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: "linear"
            }}
            style={{ transformStyle: 'preserve-3d' }}
          >
            <div className="text-6xl">📊</div>
          </motion.div>

          <h2 className="text-4xl sm:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
            أرقام تتحدث عن نفسها
          </h2>
          <p className="text-muted-foreground text-xl max-w-3xl mx-auto leading-relaxed">
            إنجازات حقيقية ونمو مستمر في رحلة التميز التعليمي
          </p>
        </motion.div>

        <div 
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8"
          style={{
            perspective: '2000px',
            transformStyle: 'preserve-3d',
          }}
        >
          {stats.map((stat, index) => (
            <StatCard key={index} stat={stat} index={index} />
          ))}
        </div>

        {/* Live indicator */}
        <motion.div
          className="mt-16 flex items-center justify-center gap-3 text-muted-foreground"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.8 }}
        >
          <motion.div
            className="w-3 h-3 rounded-full bg-green-500"
            animate={{
              scale: [1, 1.3, 1],
              opacity: [1, 0.6, 1],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
            }}
          />
          <span>البيانات محدثة لحظياً</span>
        </motion.div>
      </div>
    </section>
  );
}
