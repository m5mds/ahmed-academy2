import { motion, useMotionValue, useSpring, useTransform } from 'motion/react';
import { Card } from './ui/card';
import { Quote, Star } from 'lucide-react';
import { useRef } from 'react';

const testimonials = [
  {
    name: 'محمد العتيبي',
    role: 'طالب ثانوية عامة',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop',
    content: 'أكاديمية أحمد غيرت طريقة دراستي تماماً. الشرح واضح والمنصة سهلة الاستخدام. حصلت على 98% بفضل المحتوى المميز!',
    rating: 5,
  },
  {
    name: 'فاطمة السعيد',
    role: 'طالبة جامعية',
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
    content: 'نظام الحماية والجودة العالية للفيديوهات يعطيني ثقة كبيرة. التطبيق سريع ويعمل بشكل ممتاز حتى على الجوال.',
    rating: 5,
  },
  {
    name: 'عبدالله الشمري',
    role: 'ولي أمر',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop',
    content: 'كولي أمر، أشعر بالاطمئنان لجودة المحتوى والحماية المتقدمة. أبنائي يتقدمون بشكل ملحوظ بفضل المتابعة المستمرة.',
    rating: 5,
  },
  {
    name: 'نورة المطيري',
    role: 'طالبة متفوقة',
    image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop',
    content: 'الدروس المباشرة والتسجيلات المحفوظة ساعدتني كثيراً في المراجعة. الشهادات المعتمدة أضافت قيمة كبيرة لسيرتي الذاتية.',
    rating: 5,
  },
];

function TestimonialCard({ testimonial, index }: { testimonial: typeof testimonials[0], index: number }) {
  const cardRef = useRef<HTMLDivElement>(null);
  
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const rotateX = useSpring(useTransform(mouseY, [-0.5, 0.5], ['15deg', '-15deg']));
  const rotateY = useSpring(useTransform(mouseX, [-0.5, 0.5], ['-15deg', '15deg']));

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    
    const rect = cardRef.current.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    
    const mouseXPos = e.clientX - rect.left;
    const mouseYPos = e.clientY - rect.top;
    
    const xPct = mouseXPos / width - 0.5;
    const yPct = mouseYPos / height - 0.5;
    
    mouseX.set(xPct);
    mouseY.set(yPct);
  };

  const handleMouseLeave = () => {
    mouseX.set(0);
    mouseY.set(0);
  };

  return (
    <motion.div
      ref={cardRef}
      initial={{ opacity: 0, y: 50, rotateX: 30, scale: 0.9 }}
      whileInView={{ opacity: 1, y: 0, rotateX: 0, scale: 1 }}
      viewport={{ once: true, margin: '-100px' }}
      transition={{ 
        duration: 0.8, 
        delay: index * 0.1,
        type: "spring",
        stiffness: 80,
      }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{
        rotateX,
        rotateY,
        transformStyle: 'preserve-3d',
      }}
    >
      <Card className="p-8 h-full hover:shadow-2xl transition-all duration-300 border-border/50 relative overflow-hidden group bg-gradient-to-br from-background to-secondary/10">
        {/* Quote background */}
        <Quote className="absolute top-4 left-4 w-16 h-16 text-primary/5 group-hover:text-primary/10 transition-colors group-hover:scale-110 duration-300" 
          style={{
            transform: 'translateZ(-10px)',
          }}
        />
        
        {/* Glow effect */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-br from-blue-500/0 via-purple-500/0 to-pink-500/0 group-hover:from-blue-500/5 group-hover:via-purple-500/5 group-hover:to-pink-500/5 transition-all duration-500"
        />

        {/* Shine effect */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full"
          transition={{ duration: 1 }}
        />
        
        <div className="relative">
          {/* User info */}
          <motion.div 
            className="flex items-center gap-4 mb-6"
            style={{
              transform: 'translateZ(40px)',
              transformStyle: 'preserve-3d',
            }}
          >
            <motion.div
              whileHover={{ scale: 1.15, rotateZ: 5 }}
              transition={{ type: "spring", stiffness: 400 }}
              style={{
                transformStyle: 'preserve-3d',
              }}
            >
              <div className="relative">
                <img
                  src={testimonial.image}
                  alt={testimonial.name}
                  className="w-16 h-16 rounded-full object-cover ring-4 ring-primary/20"
                />
                {/* Image glow */}
                <motion.div
                  className="absolute inset-0 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 opacity-0 group-hover:opacity-30 blur-xl"
                  animate={{
                    scale: [1, 1.2, 1],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                  }}
                />
              </div>
            </motion.div>
            
            <div>
              <h4 className="font-bold text-lg">{testimonial.name}</h4>
              <p className="text-sm text-muted-foreground">{testimonial.role}</p>
            </div>
          </motion.div>

          {/* Content */}
          <motion.p 
            className="text-muted-foreground leading-relaxed mb-6 text-base"
            style={{
              transform: 'translateZ(30px)',
            }}
          >
            "{testimonial.content}"
          </motion.p>

          {/* Rating */}
          <motion.div 
            className="flex gap-1"
            style={{
              transform: 'translateZ(50px)',
              transformStyle: 'preserve-3d',
            }}
          >
            {Array.from({ length: testimonial.rating }).map((_, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, scale: 0, rotateY: -180 }}
                whileInView={{ opacity: 1, scale: 1, rotateY: 0 }}
                viewport={{ once: true }}
                transition={{ 
                  delay: 0.8 + index * 0.1 + i * 0.1,
                  type: "spring",
                  stiffness: 200,
                }}
                whileHover={{ 
                  scale: 1.3,
                  rotateZ: 15,
                }}
              >
                <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Decorative gradient corner */}
        <motion.div
          className="absolute -bottom-8 -left-8 w-32 h-32 rounded-full bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 opacity-0 group-hover:opacity-20 blur-3xl"
          style={{
            transform: 'translateZ(-15px)',
          }}
        />
      </Card>
    </motion.div>
  );
}

export function Testimonials() {
  return (
    <section className="py-32 bg-gradient-to-b from-secondary/20 via-background to-secondary/10 relative overflow-hidden">
      {/* Animated particles */}
      {[...Array(30)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-primary/30 rounded-full"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          animate={{
            y: [0, -50, 0],
            opacity: [0, 1, 0],
            scale: [0, 1.5, 0],
          }}
          transition={{
            duration: 4 + Math.random() * 3,
            repeat: Infinity,
            delay: Math.random() * 5,
          }}
        />
      ))}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <motion.div
            className="inline-flex items-center gap-3 mb-6"
            animate={{
              y: [-5, 5, -5],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            {['⭐', '⭐', '⭐', '⭐', '⭐'].map((star, i) => (
              <motion.span
                key={i}
                className="text-4xl"
                animate={{
                  rotateY: [0, 360],
                }}
                transition={{
                  duration: 3,
                  repeat: Infinity,
                  delay: i * 0.2,
                  ease: "linear"
                }}
                style={{ transformStyle: 'preserve-3d' }}
              >
                {star}
              </motion.span>
            ))}
          </motion.div>

          <h2 className="text-4xl sm:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
            ماذا يقول طلابنا
          </h2>
          <p className="text-muted-foreground text-xl max-w-3xl mx-auto leading-relaxed">
            آلاف الطلاب حققوا أهدافهم التعليمية معنا - هذه بعض قصص نجاحهم
          </p>
        </motion.div>

        <div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8"
          style={{
            perspective: '2000px',
            transformStyle: 'preserve-3d',
          }}
        >
          {testimonials.map((testimonial, index) => (
            <TestimonialCard key={index} testimonial={testimonial} index={index} />
          ))}
        </div>

        {/* Trust badge */}
        <motion.div
          className="mt-16 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.6 }}
        >
          <motion.div
            className="inline-flex items-center gap-3 bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-pink-500/10 border border-primary/20 px-8 py-4 rounded-full"
            whileHover={{ 
              scale: 1.05,
              boxShadow: '0 20px 40px rgba(0,0,0,0.1)',
            }}
            style={{
              transformStyle: 'preserve-3d',
            }}
          >
            <motion.div
              animate={{
                rotateY: [0, 360],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "linear"
              }}
            >
              ✅
            </motion.div>
            <span className="font-semibold">تقييم 4.9/5 من أكثر من 2000 مراجعة</span>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
