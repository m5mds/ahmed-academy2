import { motion, useMotionValue, useSpring, useTransform } from 'motion/react';
import { Card } from './ui/card';
import { Shield, Lock, Zap, Award, Clock, Smartphone } from 'lucide-react';
import { useState, useRef } from 'react';

const features = [
  {
    icon: Shield,
    title: 'حماية المحتوى المتقدمة',
    description: 'تقنية JWS للتوقيع الرقمي مع روابط منتهية الصلاحية لحماية الملكية الفكرية',
    color: 'from-blue-500 to-cyan-500',
  },
  {
    icon: Lock,
    title: 'نظام الاشتراكات الذكي',
    description: 'خطط متعددة المستويات (MID1, MID2, FINAL, FULL) مع تحكم دقيق في الوصول',
    color: 'from-purple-500 to-pink-500',
  },
  {
    icon: Zap,
    title: 'حضور تلقائي عبر Zoom',
    description: 'تتبع تلقائي للحضور والمشاركة في الدروس المباشرة بدون تدخل يدوي',
    color: 'from-orange-500 to-red-500',
  },
  {
    icon: Award,
    title: 'شهادات معتمدة',
    description: 'احصل على شهادة إتمام رقمية بعد إكمال 100% من المحتوى',
    color: 'from-green-500 to-emerald-500',
  },
  {
    icon: Clock,
    title: 'استكمال تلقائي',
    description: 'احفظ تقدمك بدقة الثانية واستكمل من حيث توقفت على أي جهاز',
    color: 'from-indigo-500 to-blue-500',
  },
  {
    icon: Smartphone,
    title: 'تطبيق PWA',
    description: 'تجربة تطبيق أصلي على جوالك مع وضع دون اتصال ودعم RTL كامل',
    color: 'from-teal-500 to-cyan-500',
  },
];

function FeatureCard({ feature, index }: { feature: typeof features[0], index: number }) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [isHovered, setIsHovered] = useState(false);

  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const mouseXSpring = useSpring(x);
  const mouseYSpring = useSpring(y);

  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ['7.5deg', '-7.5deg']);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ['-7.5deg', '7.5deg']);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;

    const rect = cardRef.current.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;

    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const xPct = mouseX / width - 0.5;
    const yPct = mouseY / height - 0.5;

    x.set(xPct);
    y.set(yPct);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
    setIsHovered(false);
  };

  return (
    <motion.div
      ref={cardRef}
      initial={{ opacity: 0, y: 50, rotateX: -10 }}
      whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
      viewport={{ once: true, margin: '-100px' }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={handleMouseLeave}
      style={{
        transformStyle: 'preserve-3d',
        rotateX,
        rotateY,
      }}
      className="h-full"
    >
      <Card className="p-8 h-full hover:shadow-2xl transition-all duration-300 border-border/50 group cursor-pointer relative overflow-hidden bg-gradient-to-br from-background to-secondary/20">
        {/* Glowing effect on hover */}
        <motion.div
          className={`absolute inset-0 bg-gradient-to-br ${feature.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`}
          animate={isHovered ? {
            scale: [1, 1.5, 1],
          } : {}}
          transition={{ duration: 2, repeat: Infinity }}
        />

        {/* Shine effect */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full"
          animate={isHovered ? {
            translateX: ['100%', '200%'],
          } : {}}
          transition={{ duration: 1, ease: "easeInOut" }}
        />

        <motion.div
          style={{
            transform: 'translateZ(75px)',
            transformStyle: 'preserve-3d',
          }}
        >
          <motion.div
            className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${feature.color} p-3.5 mb-6 shadow-lg group-hover:shadow-2xl transition-all relative`}
            whileHover={{ 
              scale: 1.1,
              rotateZ: 360,
            }}
            transition={{ 
              rotateZ: { duration: 0.6, ease: "easeOut" },
              scale: { duration: 0.2 }
            }}
            style={{
              transform: 'translateZ(50px)',
            }}
          >
            <feature.icon className="w-full h-full text-white" />
            
            {/* Icon glow */}
            <motion.div
              className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${feature.color} blur-xl opacity-0 group-hover:opacity-50`}
              animate={isHovered ? {
                scale: [1, 1.2, 1],
              } : {}}
              transition={{ duration: 2, repeat: Infinity }}
            />
          </motion.div>
        </motion.div>

        <motion.div
          style={{
            transform: 'translateZ(50px)',
            transformStyle: 'preserve-3d',
          }}
        >
          <h3 className="text-2xl font-semibold mb-3">{feature.title}</h3>
          <p className="text-muted-foreground leading-relaxed text-base">
            {feature.description}
          </p>
        </motion.div>

        {/* Corner accent */}
        <motion.div
          className={`absolute -bottom-8 -left-8 w-24 h-24 bg-gradient-to-br ${feature.color} rounded-full blur-2xl opacity-0 group-hover:opacity-30 transition-opacity duration-500`}
          style={{
            transform: 'translateZ(-10px)',
          }}
        />
      </Card>
    </motion.div>
  );
}

export function Features() {
  return (
    <section className="py-32 bg-gradient-to-b from-background via-secondary/10 to-background relative overflow-hidden">
      {/* Animated background grid */}
      <div className="absolute inset-0 opacity-[0.02]">
        <div className="absolute inset-0" style={{
          backgroundImage: 'linear-gradient(to right, currentColor 1px, transparent 1px), linear-gradient(to bottom, currentColor 1px, transparent 1px)',
          backgroundSize: '40px 40px',
        }} />
      </div>

      {/* Floating particles */}
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 bg-primary/20 rounded-full"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          animate={{
            y: [0, -100, 0],
            opacity: [0, 1, 0],
            scale: [0, 1, 0],
          }}
          transition={{
            duration: 5 + Math.random() * 5,
            repeat: Infinity,
            delay: Math.random() * 5,
          }}
        />
      ))}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <motion.div
            className="inline-block"
            animate={{
              rotateY: [0, 360],
            }}
            transition={{
              duration: 20,
              repeat: Infinity,
              ease: "linear"
            }}
            style={{ transformStyle: 'preserve-3d' }}
          >
            <div className="text-6xl mb-4">✨</div>
          </motion.div>
          <h2 className="text-4xl sm:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
            مميزات تجعلنا الأفضل
          </h2>
          <p className="text-muted-foreground text-xl max-w-3xl mx-auto leading-relaxed">
            بنية تحتية تعليمية متطورة مع حماية فائقة للمحتوى وتجربة مستخدم استثنائية
          </p>
        </motion.div>

        <div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          style={{ 
            perspective: '1000px',
            transformStyle: 'preserve-3d',
          }}
        >
          {features.map((feature, index) => (
            <FeatureCard key={index} feature={feature} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
