import { motion } from 'motion/react';
import { Button } from './ui/button';
import { Menu, X, Moon, Sun, GraduationCap } from 'lucide-react';
import { useState, useEffect } from 'react';

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [isDark, setIsDark] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 10);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleTheme = () => {
    setIsDark(!isDark);
    document.documentElement.classList.toggle('dark');
  };

  const navLinks = [
    { name: 'الرئيسية', href: '#' },
    { name: 'الدورات', href: '#' },
    { name: 'الباقات', href: '#' },
    { name: 'عن الأكاديمية', href: '#' },
    { name: 'اتصل بنا', href: '#' },
  ];

  return (
    <motion.nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-background/95 backdrop-blur-md shadow-lg border-b border-border/50'
          : 'bg-transparent'
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <motion.div
            className="flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-lg">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <span className={`text-xl font-bold ${scrolled ? 'text-foreground' : 'text-white'}`}>
              أكاديمية أحمد
            </span>
          </motion.div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6">
            {navLinks.map((link, index) => (
              <motion.a
                key={index}
                href={link.href}
                className={`transition-colors ${
                  scrolled
                    ? 'text-foreground hover:text-primary'
                    : 'text-white/90 hover:text-white'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {link.name}
              </motion.a>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3">
            <motion.button
              onClick={toggleTheme}
              className={`p-2 rounded-lg transition-colors ${
                scrolled
                  ? 'hover:bg-secondary'
                  : 'hover:bg-white/10'
              }`}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              {isDark ? (
                <Sun className={`w-5 h-5 ${scrolled ? 'text-foreground' : 'text-white'}`} />
              ) : (
                <Moon className={`w-5 h-5 ${scrolled ? 'text-foreground' : 'text-white'}`} />
              )}
            </motion.button>

            <div className="hidden md:flex items-center gap-2">
              <Button
                variant="ghost"
                className={scrolled ? '' : 'text-white hover:bg-white/10'}
              >
                تسجيل الدخول
              </Button>
              <Button className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white shadow-lg">
                تسجيل مجاني
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className={`md:hidden p-2 rounded-lg transition-colors ${
                scrolled ? 'hover:bg-secondary' : 'hover:bg-white/10'
              }`}
            >
              {isOpen ? (
                <X className={`w-6 h-6 ${scrolled ? 'text-foreground' : 'text-white'}`} />
              ) : (
                <Menu className={`w-6 h-6 ${scrolled ? 'text-foreground' : 'text-white'}`} />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <motion.div
        initial={false}
        animate={{
          height: isOpen ? 'auto' : 0,
          opacity: isOpen ? 1 : 0,
        }}
        transition={{ duration: 0.3 }}
        className="md:hidden overflow-hidden bg-background/95 backdrop-blur-md border-t border-border/50"
      >
        <div className="px-4 py-4 space-y-3">
          {navLinks.map((link, index) => (
            <a
              key={index}
              href={link.href}
              className="block py-2 text-foreground hover:text-primary transition-colors"
            >
              {link.name}
            </a>
          ))}
          <div className="pt-3 space-y-2 border-t border-border/50">
            <Button variant="outline" className="w-full">
              تسجيل الدخول
            </Button>
            <Button className="w-full bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white">
              تسجيل مجاني
            </Button>
          </div>
        </div>
      </motion.div>
    </motion.nav>
  );
}
