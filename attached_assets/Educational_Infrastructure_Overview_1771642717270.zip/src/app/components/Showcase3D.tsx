import { motion, useScroll, useTransform } from 'motion/react';
import { useState, useRef } from 'react';
import { Shield, Lock, Video, Zap, CheckCircle2, PlayCircle } from 'lucide-react';

const steps = [
  {
    icon: Shield,
    title: 'تسجيل آمن',
    description: 'قم بإنشاء حسابك بأمان تام مع حماية بياناتك',
    color: 'from-blue-500 to-cyan-500',
  },
  {
    icon: Lock,
    title: 'اختر باقتك',
    description: 'اختر الباقة المناسبة وقم بالدفع الآمن',
    color: 'from-purple-500 to-pink-500',
  },
  {
    icon: Video,
    title: 'ابدأ التعلم',
    description: 'وصول فوري لجميع الدروس والمحتوى الحصري',
    color: 'from-orange-500 to-red-500',
  },
  {
    icon: CheckCircle2,
    title: 'احصل على شهادتك',
    description: 'أكمل المسار واحصل على شهادة معتمدة',
    color: 'from-green-500 to-emerald-500',
  },
];

export function Showcase3D() {
  const containerRef = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start end", "end start"]
  });

  const rotateX = useTransform(scrollYProgress, [0, 0.5, 1], [20, 0, -20]);
  const y = useTransform(scrollYProgress, [0, 1], [-100, 100]);

  return (
    <section ref={containerRef} className="py-32 bg-gradient-to-b from-background to-secondary/20 relative overflow-hidden">
      {/* Animated 3D Grid Background */}
      <motion.div 
        className="absolute inset-0"
        style={{
          perspective: '1000px',
          transformStyle: 'preserve-3d',
        }}
      >
        <motion.div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `
              linear-gradient(to right, currentColor 1px, transparent 1px),
              linear-gradient(to bottom, currentColor 1px, transparent 1px)
            `,
            backgroundSize: '60px 60px',
            rotateX,
            y,
          }}
        />
      </motion.div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <motion.div
          className="text-center mb-20"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <motion.div
            animate={{
              rotateY: [0, 360],
            }}
            transition={{
              duration: 15,
              repeat: Infinity,
              ease: "linear"
            }}
            style={{ transformStyle: 'preserve-3d' }}
            className="inline-block text-6xl mb-6"
          >
            🚀
          </motion.div>
          <h2 className="text-4xl sm:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
            كيف تبدأ رحلتك معنا؟
          </h2>
          <p className="text-muted-foreground text-xl max-w-3xl mx-auto">
            خطوات بسيطة تفصلك عن عالم من المعرفة والتميز الأكاديمي
          </p>
        </motion.div>

        {/* 3D Steps Flow */}
        <div className="relative">
          {/* Connecting Line */}
          <div className="hidden lg:block absolute top-1/2 left-0 right-0 h-1 bg-gradient-to-r from-blue-500 via-purple-500 via-orange-500 to-green-500 -translate-y-1/2 opacity-20" />

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <StepCard key={index} step={step} index={index} />
            ))}
          </div>
        </div>

        {/* CTA Video Section */}
        <motion.div
          className="mt-24 relative"
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <VideoShowcase />
        </motion.div>
      </div>
    </section>
  );
}

function StepCard({ step, index }: { step: typeof steps[0], index: number }) {
  const [isHovered, setIsHovered] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  return (
    <motion.div
      ref={cardRef}
      className="relative"
      initial={{ opacity: 0, y: 100, rotateX: 45 }}
      whileInView={{ opacity: 1, y: 0, rotateX: 0 }}
      viewport={{ once: true, margin: '-100px' }}
      transition={{ 
        duration: 0.8, 
        delay: index * 0.2,
        type: "spring",
        stiffness: 100,
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      style={{
        transformStyle: 'preserve-3d',
      }}
    >
      {/* Step Number */}
      <motion.div
        className="absolute -top-6 right-1/2 translate-x-1/2 w-12 h-12 rounded-full bg-gradient-to-br from-primary to-primary/50 flex items-center justify-center text-white font-bold text-xl shadow-2xl z-10"
        animate={isHovered ? {
          scale: [1, 1.2, 1],
          rotateY: 360,
        } : {}}
        transition={{ duration: 0.6 }}
        style={{
          transform: 'translateZ(50px)',
          transformStyle: 'preserve-3d',
        }}
      >
        {index + 1}
      </motion.div>

      <motion.div
        className="bg-card border border-border/50 rounded-3xl p-8 pt-12 text-center h-full relative overflow-hidden"
        animate={isHovered ? {
          y: -10,
          rotateX: 5,
          rotateY: 5,
        } : {
          rotateX: 0,
          rotateY: 0,
        }}
        transition={{ type: "spring", stiffness: 300 }}
        style={{
          transformStyle: 'preserve-3d',
        }}
      >
        {/* Background gradient */}
        <motion.div
          className={`absolute inset-0 bg-gradient-to-br ${step.color} opacity-0`}
          animate={isHovered ? { opacity: 0.1 } : { opacity: 0 }}
        />

        {/* Icon */}
        <motion.div
          className={`w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-br ${step.color} p-4 shadow-2xl relative`}
          animate={isHovered ? {
            rotateZ: 360,
            scale: 1.1,
          } : {}}
          transition={{ duration: 0.6 }}
          style={{
            transform: 'translateZ(40px)',
            transformStyle: 'preserve-3d',
          }}
        >
          <step.icon className="w-full h-full text-white" />
          
          {/* Glow effect */}
          <motion.div
            className={`absolute inset-0 rounded-2xl bg-gradient-to-br ${step.color} blur-2xl`}
            animate={isHovered ? {
              scale: [1, 1.5, 1],
              opacity: [0.3, 0.6, 0.3],
            } : {}}
            transition={{ duration: 2, repeat: Infinity }}
          />
        </motion.div>

        <motion.div
          style={{
            transform: 'translateZ(30px)',
          }}
        >
          <h3 className="text-2xl font-bold mb-3">{step.title}</h3>
          <p className="text-muted-foreground leading-relaxed">{step.description}</p>
        </motion.div>

        {/* Corner decoration */}
        <motion.div
          className={`absolute bottom-0 right-0 w-32 h-32 bg-gradient-to-br ${step.color} rounded-tl-full opacity-0 blur-2xl`}
          animate={isHovered ? { opacity: 0.2 } : { opacity: 0 }}
          style={{
            transform: 'translateZ(-10px)',
          }}
        />
      </motion.div>
    </motion.div>
  );
}

function VideoShowcase() {
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <motion.div
      className="relative max-w-5xl mx-auto"
      style={{
        transformStyle: 'preserve-3d',
        perspective: '1000px',
      }}
    >
      <motion.div
        className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-primary/20"
        whileHover={{
          rotateY: 2,
          rotateX: -2,
          scale: 1.02,
        }}
        transition={{ type: "spring", stiffness: 300 }}
        style={{
          transformStyle: 'preserve-3d',
        }}
      >
        {/* Video Placeholder */}
        <div className="relative aspect-video bg-gradient-to-br from-blue-600 via-purple-700 to-pink-700">
          <motion.div
            className="absolute inset-0 flex items-center justify-center"
            animate={{
              background: [
                'radial-gradient(circle at 30% 50%, rgba(255,255,255,0.1) 0%, transparent 50%)',
                'radial-gradient(circle at 70% 50%, rgba(255,255,255,0.1) 0%, transparent 50%)',
                'radial-gradient(circle at 30% 50%, rgba(255,255,255,0.1) 0%, transparent 50%)',
              ],
            }}
            transition={{ duration: 5, repeat: Infinity }}
          >
            <motion.button
              className="w-24 h-24 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center shadow-2xl group relative overflow-hidden"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => setIsPlaying(!isPlaying)}
              style={{
                transformStyle: 'preserve-3d',
                transform: 'translateZ(50px)',
              }}
            >
              <motion.div
                className="absolute inset-0 bg-gradient-to-r from-blue-500 to-purple-500 opacity-0 group-hover:opacity-20"
                animate={{
                  scale: [1, 1.5, 1],
                }}
                transition={{ duration: 2, repeat: Infinity }}
              />
              <PlayCircle className="w-12 h-12 text-primary fill-primary" />
            </motion.button>
          </motion.div>

          {/* Overlay text */}
          <div className="absolute bottom-8 right-8 text-white">
            <motion.h3
              className="text-3xl font-bold mb-2"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              شاهد كيف تعمل المنصة
            </motion.h3>
            <motion.p
              className="text-blue-100"
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
            >
              جولة سريعة في أكاديمية أحمد
            </motion.p>
          </div>
        </div>

        {/* Decorative elements */}
        <motion.div
          className="absolute -bottom-4 -right-4 w-32 h-32 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full blur-3xl opacity-50"
          animate={{
            scale: [1, 1.2, 1],
          }}
          transition={{ duration: 3, repeat: Infinity }}
        />
        <motion.div
          className="absolute -top-4 -left-4 w-32 h-32 bg-gradient-to-br from-blue-500 to-cyan-500 rounded-full blur-3xl opacity-50"
          animate={{
            scale: [1.2, 1, 1.2],
          }}
          transition={{ duration: 3, repeat: Infinity }}
        />
      </motion.div>

      {/* Floating badges */}
      <motion.div
        className="absolute -top-8 -right-8 bg-gradient-to-br from-green-500 to-emerald-500 text-white px-6 py-3 rounded-full shadow-2xl font-bold"
        animate={{
          y: [-5, 5, -5],
          rotateZ: [-3, 3, -3],
        }}
        transition={{ duration: 3, repeat: Infinity }}
        style={{
          transform: 'translateZ(60px)',
        }}
      >
        ✅ دقيقتان فقط
      </motion.div>

      <motion.div
        className="absolute -bottom-8 -left-8 bg-gradient-to-br from-orange-500 to-red-500 text-white px-6 py-3 rounded-full shadow-2xl font-bold"
        animate={{
          y: [5, -5, 5],
          rotateZ: [3, -3, 3],
        }}
        transition={{ duration: 3, repeat: Infinity, delay: 0.5 }}
        style={{
          transform: 'translateZ(60px)',
        }}
      >
        🎓 سهل وبسيط
      </motion.div>
    </motion.div>
  );
}
